package proyect.appRestProducts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppRestProductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppRestProductsApplication.class, args);
	}

}
